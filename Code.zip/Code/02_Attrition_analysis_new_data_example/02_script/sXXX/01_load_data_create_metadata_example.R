#------------------------------------------------------------------------------#
# TITLE:      01_load_data_create_metadata.R                                   #
# PURPOSE:    Load data into environment and create a metadata overview con-   #
#             taining all relevant information about the survey rounds.        #
# INPUTS:     Survey data including the variables to analyze and response      #
#             status columns for each survey round.                            #
#             Please adapt metadata manually in Section 2.                     #
# OUTPUTS:    <data_wide_formatted> containing the survey data.                #
#             <waves>: a dataframe containing relevant metadata about the      #
#             survey rounds.                                                   #                      
# PUBLISHED:  2021-04-21                                                       # 
# AUTHOR:     Janina Roemer                                                    #
#------------------------------------------------------------------------------#



## Section 1: Loading the data to the environment ##############################
data_wide_formatted <- read.csv(paste0(raw, "/example_data.csv"))


## Section 2: Summing up relevant metadata about the survey rounds  ############
##            Create a dataframe "waves" containing the following metadata in ##
##            chronological order:                                            ##

# Short name of each survey round.
wave_name <- c("baseline", "r1", "r2", "r3", "r4", "r5", "r6", "r7")

# Start date of the data collection period of each round
date <- c("2014-10-01", "2014-11-01", "2014-12-01", "2015-01-01", "2015-02-01", 
          "2015-03-01", "2015-04-01", "2015-05-01") 

# Time difference between each round and the baseline In DAYS (starting days)
time_from_BL <- as.numeric(as.Date(date, "%Y-%m-%d")) - 
  rep(as.numeric(as.Date("2014-10-01", "%Y-%m-%d"), length(date)))

# Time difference between each round and the baseline In full MONTHS. Rounded 
# to integers due to low metadata precision. 
months_from_BL <- round(time_from_BL/30.5)

waves <- data.frame(wave_name, months_from_BL, date,  stringsAsFactors = FALSE)                                   # Combining the vectors to one dataframe

# Adding long names to the dataframe. These will be used as tick labels in plots.
waves$long_name <- c("Baseline\n(Face to Face)", "Round 1", "Round 2", "Round 3", 
                     "Round 4", "Round 5", "Round 6", "Round 7")

# Add wave number, extracting it from wave_name
waves$wave_number <- rep(NA, length(wave_name))
waves$wave_number[1] <- 0
waves$wave_number[2:nrow(waves)] <- wave_name[2:nrow(waves)] %>%  
  sapply(function(x) sub("r", "", x, fixed = T)) 
waves$wave_number <- waves$wave_number %>% as.numeric(waves$wave_number)

# create study ID
study_id <- "sXXX"
